# Tiratwist Southeast

Static website for Tiratwist Southeast (tiramisu twists). Plain HTML, CSS and JavaScript. No build step.

## Structure
- `index.html` home page
- `flavors.html`, `story.html`, `order.html`
- flavor pages: toffee, tella, strawberry, cookie-butter, cookie-cream, dubai (.html)
- `style.css`, `app.js`
- images (.png, .jpg)

## Deploy
- **Vercel:** import the repo, Framework Preset "Other", leave build command and output directory empty.
- **GitHub Pages:** Settings → Pages → Deploy from branch → `main` / root.

## Contact
470-291-0101 · info@tiratwist-se.com
