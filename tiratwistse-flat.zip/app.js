(function(){
var d=document,rm=matchMedia('(prefers-reduced-motion:reduce)').matches;
/* page wipe */
var w=d.createElement('div');w.className='wipe out';d.body.appendChild(w);
setTimeout(function(){w.className='wipe'},760);
addEventListener('pageshow',function(e){if(e.persisted){w.className='wipe'}});
d.addEventListener('click',function(e){
 var b=e.target.closest('.copy');
 if(b){var t=b.dataset.copy;var ok=function(){var o=b.textContent;b.textContent='Copied';setTimeout(function(){b.textContent='Copy'},1600)};
  try{navigator.clipboard.writeText(t).then(ok,function(){})}catch(x){}return}
 var a=e.target.closest('a[href]');if(!a||e.defaultPrevented||e.metaKey||e.ctrlKey||e.shiftKey||e.button)return;
 var h=a.getAttribute('href');
 if(!h||h[0]==='#'||/^(mailto:|tel:)/.test(h)||a.target==='_blank'||/^https?:/.test(h))return;
 if(rm)return;
 e.preventDefault();w.className='wipe in';setTimeout(function(){location.href=a.href},560);
});
/* cursor blob */
if(!rm&&matchMedia('(hover:hover)').matches){
 var c=d.createElement('div');c.className='cur';d.body.appendChild(c);
 var mx=-100,my=-100,cx=-100,cy=-100;
 addEventListener('mousemove',function(e){mx=e.clientX-17;my=e.clientY-17;pm(e)});
 (function loop(){cx+=(mx-cx)*.2;cy+=(my-cy)*.2;c.style.transform='translate3d('+cx+'px,'+cy+'px,0)';requestAnimationFrame(loop)})();
 d.addEventListener('mouseover',function(e){c.classList.toggle('big2',!!e.target.closest('a,button,.pill'))});
}
/* mouse parallax on floats */
var fl=[].slice.call(d.querySelectorAll('.float'));
function pm(e){if(!fl.length)return;var x=(e.clientX/innerWidth-.5),y=(e.clientY/innerHeight-.5);
 fl.forEach(function(f,i){var k=(i+1)*22;f.style.translate=(-x*k)+'px '+(-y*k)+'px'})}
/* reveal: visible at rest; only below-the-fold items animate in */
var rvs=[].slice.call(d.querySelectorAll('.rv'));
function revealCheck(){rvs.forEach(function(n){if(n.classList.contains('rvh')&&!n.classList.contains('in')&&n.getBoundingClientRect().top<innerHeight*.92)n.classList.add('in')})}
rvs.forEach(function(n){if(n.getBoundingClientRect().top>innerHeight*.95)n.classList.add('rvh')});
addEventListener('scroll',revealCheck,{passive:true,capture:true});addEventListener('resize',revealCheck);
setInterval(revealCheck,600);
/* word-by-word scroll lighting: text stays fully visible until the page is actually scrolled */
var sp=d.querySelector('[data-rw]');
if(sp){
 var words=[];
 [].slice.call(sp.childNodes).forEach(function(n){
  if(n.nodeType===3){var frag=d.createDocumentFragment();
   n.textContent.split(/(\s+)/).forEach(function(t){if(!t)return;if(/^\s+$/.test(t)){frag.appendChild(d.createTextNode(' '))}else{var s=d.createElement('span');s.className='rw lit';s.textContent=t;frag.appendChild(s);words.push(s)}});
   sp.replaceChild(frag,n)}
 });
 var tick=function(){var r=sp.getBoundingClientRect(),vh=innerHeight;
  var p=(vh*.9-r.top)/(r.height+vh*.2);p=Math.max(0,Math.min(1,p));
  var n=Math.round(p*words.length);words.forEach(function(s,i){s.classList.toggle('lit',i<n)})};
 var armed=false;
 addEventListener('scroll',function(){if(!armed){armed=true;sp.classList.add('dim')}tick()},{passive:true,capture:true});
}
})();
